# Introduction

Welcome to **Docs Unlocked**! This is a powerful documentation system built with React, TypeScript, and Tailwind CSS, designed specifically for Salesforce Lightning Web Components.

## What's Inside

Docs Unlocked provides:

- ⚡ **Fast and lightweight** - Optimized bundle size for Salesforce
- 📝 **Markdown support** - Full GitHub Flavored Markdown (GFM) support
- 🎨 **Beautiful UI** - Modern, responsive design with Tailwind CSS
- 🔒 **Salesforce-ready** - Built to run seamlessly in Salesforce orgs
- 📱 **Mobile-friendly** - Responsive design that works on all devices
- 🔍 **Runtime discovery** - Navigation automatically generated from your content structure

## Key Features

### Markdown Rendering

Docs Unlocked uses `marked.js` with the same configuration as the popular [Markdown-Unlocked](https://github.com/Nimba-Solutions/Markdown-Unlocked) package:

- **GitHub Flavored Markdown** - Tables, task lists, strikethrough, and more
- **Automatic line breaks** - Better readability
- **Code syntax highlighting** - Powered by highlight.js
- **Safe HTML rendering** - Sanitized with DOMPurify

### Architecture

```
┌─────────────────┐
│   Salesforce    │
│      LWC        │
└────────┬────────┘
         │
         │ Loads bundle
         ▼
┌─────────────────┐
│  React Bundle   │
│  (StaticResource)│
└────────┬────────┘
         │
         │ Renders
         ▼
┌─────────────────┐
│  Documentation   │
│     Content      │
└─────────────────┘
```

### Runtime Navigation Discovery

Docs Unlocked automatically discovers your content structure at runtime. Simply organize your markdown files in directories, and navigation is generated automatically. No manual configuration needed!

## Quick Start

1. **Deploy to Salesforce**
   ```bash
   npm run build:sf
   cci task run deploy --path force-app --org dev
   ```

2. **Add your content** - Place markdown files in `public/content/` with numerical prefixes for ordering

3. **Enjoy!** - Navigation is automatically generated from your file structure

## Next Steps

:::navcards
title: Contributing
description: Learn how to contribute to Docs Unlocked
href: /getting-started/contributing
---
title: Basic Usage
description: Learn how to add content and structure your documentation
href: /core-concepts/basic-usage
---
title: Configuration
description: Customize your documentation settings and appearance
href: /core-concepts/configuration
:::

---

> 💡 **Tip**: Navigation is automatically generated from your content directory structure. Use numerical prefixes (like `01-`, `02-`) to control the order of sections and pages.
